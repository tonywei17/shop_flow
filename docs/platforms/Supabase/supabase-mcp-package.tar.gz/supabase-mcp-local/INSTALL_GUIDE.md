# Supabase MCP 安装指南（团队版）

## 📦 获取安装包

从团队共享位置获取 `supabase-mcp-package.tar.gz` 文件

## 🚀 安装步骤

### 1. 解压安装包

```bash
cd ~
tar -xzf ~/Downloads/supabase-mcp-package.tar.gz
```

这会在你的主目录创建 `~/supabase-mcp-local/` 文件夹

### 2. 重新创建虚拟环境

由于Python虚拟环境包含硬编码路径，需要重新创建：

```bash
cd ~/supabase-mcp-local
rm -rf venv
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 3. 测试连接

```bash
cd ~/supabase-mcp-local
source venv/bin/activate
python3 test_local.py
```

应该看到：
```
✅ All tests passed!
```

### 4. 配置Windsurf

打开或创建Windsurf的MCP配置文件：

**配置文件路径：**
```
~/Library/Application Support/Windsurf/User/globalStorage/codeium.windsurf/config/mcp_config.json
```

**配置内容：**

⚠️ **重要**：将 `/Users/wenxinwei` 替换成**你的用户名**！

```json
{
  "mcpServers": {
    "supabase-local": {
      "command": "/Users/你的用户名/supabase-mcp-local/venv/bin/python",
      "args": [
        "/Users/你的用户名/supabase-mcp-local/server.py"
      ],
      "env": {
        "SUPABASE_URL": "https://supabase-api.nexus-tech.cloud",
        "SUPABASE_SERVICE_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoic2VydmljZV9yb2xlIiwiaXNzIjoic3VwYWJhc2UiLCJpYXQiOjE2NDE3NjkyMDAsImV4cCI6MTc5OTUzNTYwMH0.d154rW2zWFTARtKnztZLuuV6Bv3qCsLAPVbGLTyYA98"
      }
    }
  }
}
```

### 5. 获取你的用户名

不确定你的用户名？运行：

```bash
echo $USER
```

或者

```bash
whoami
```

### 6. 完整配置示例

假设你的用户名是 `zhangsan`，配置应该是：

```json
{
  "mcpServers": {
    "supabase-local": {
      "command": "/Users/zhangsan/supabase-mcp-local/venv/bin/python",
      "args": [
        "/Users/zhangsan/supabase-mcp-local/server.py"
      ],
      "env": {
        "SUPABASE_URL": "https://supabase-api.nexus-tech.cloud",
        "SUPABASE_SERVICE_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoic2VydmljZV9yb2xlIiwiaXNzIjoic3VwYWJhc2UiLCJpYXQiOjE2NDE3NjkyMDAsImV4cCI6MTc5OTUzNTYwMH0.d154rW2zWFTARtKnztZLuuV6Bv3qCsLAPVbGLTyYA98"
      }
    }
  }
}
```

### 7. 重启Windsurf

完全退出Windsurf（Cmd+Q），然后重新启动。

## 🧪 验证安装

在Windsurf的AI对话中测试：

```
使用supabase-local的list_tables工具列出所有表
```

应该能看到：department_members, departments, roles, user_profiles 等表。

## 📋 可用工具

安装完成后，可以使用以下8个工具：

1. **read_table_rows** - 读取表数据
2. **create_table_records** - 插入记录
3. **update_table_records** - 更新记录
4. **delete_table_records** - 删除记录
5. **execute_sql** - 执行任意SQL
6. **list_tables** - 列出所有表
7. **describe_table** - 查看表结构
8. **create_table** - 创建新表

## ⚠️ 常见问题

### Q1: 提示找不到Python路径

**原因**：配置中的用户名没有改成你自己的

**解决**：
1. 运行 `whoami` 获取你的用户名
2. 将配置中的 `/Users/wenxinwei` 全部替换成 `/Users/你的用户名`

### Q2: pip install失败（externally-managed-environment错误）

这是正常的，已经在步骤2中处理。确保先删除旧的venv再重新创建。

### Q3: test_local.py测试失败

**可能原因**：
- VPS网络不通
- 虚拟环境未激活
- 依赖未安装

**解决步骤**：
```bash
cd ~/supabase-mcp-local
source venv/bin/activate
pip install -r requirements.txt
python3 test_local.py
```

### Q4: Windsurf显示MCP连接失败

**检查清单**：
1. ✅ 配置文件路径正确
2. ✅ Python路径中的用户名已修改
3. ✅ 完全退出并重启Windsurf（不是只关闭窗口）
4. ✅ 本地测试通过（test_local.py）

### Q5: 如何查看MCP日志

Windsurf会在开发者工具中显示MCP错误。可以通过Help > Toggle Developer Tools查看。

## 🔧 手动安装（如果解压失败）

如果tar包解压有问题，可以手动安装：

### 1. 创建项目目录
```bash
mkdir -p ~/supabase-mcp-local
cd ~/supabase-mcp-local
```

### 2. 创建必要文件

**requirements.txt:**
```
mcp>=1.0.0
supabase>=2.0.0
httpx>=0.24.0
```

**server.py:**
从团队共享中获取 `server.py` 文件并放到这个目录

**test_local.py:**
从团队共享中获取 `test_local.py` 文件并放到这个目录

### 3. 创建虚拟环境
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 4. 按照上面的步骤4配置Windsurf

## 📞 需要帮助？

如果安装过程中遇到问题：

1. 确认本地测试通过：`python3 test_local.py`
2. 检查配置文件路径是否正确
3. 确认用户名已替换
4. 联系团队管理员

## 🎉 安装完成！

现在你可以在Windsurf中使用Supabase MCP的所有8个工具来操作团队数据库了！

---

**数据库信息：**
- URL: https://supabase-api.nexus-tech.cloud
- 管理界面: https://supabase.nexus-tech.cloud
- 包含表：department_members, departments, roles, user_profiles
