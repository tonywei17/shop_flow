#!/bin/bash
# Supabase MCP 自动安装脚本

set -e

echo "🚀 Supabase MCP 自动安装开始..."
echo ""

# 检查是否在正确的目录
if [ ! -f "requirements.txt" ] || [ ! -f "server.py" ]; then
    echo "❌ 错误：请在 supabase-mcp-local 目录中运行此脚本"
    echo "   正确路径应该是: ~/supabase-mcp-local/"
    exit 1
fi

echo "📍 当前目录: $(pwd)"
echo ""

# 获取当前用户名
USERNAME=$(whoami)
echo "👤 检测到用户名: $USERNAME"
echo ""

# 删除旧的虚拟环境（如果存在）
if [ -d "venv" ]; then
    echo "🗑️  删除旧的虚拟环境..."
    rm -rf venv
fi

# 创建新的虚拟环境
echo "🔨 创建Python虚拟环境..."
python3 -m venv venv

# 激活虚拟环境并安装依赖
echo "📦 安装依赖包..."
source venv/bin/activate
pip install -q --upgrade pip
pip install -q -r requirements.txt

echo ""
echo "✅ 虚拟环境创建完成！"
echo ""

# 测试连接
echo "🧪 测试Supabase连接..."
python3 test_local.py

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ 安装成功！"
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "📋 下一步：配置Windsurf IDE"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo "1️⃣ 打开Windsurf配置文件："
    echo "   ~/Library/Application Support/Windsurf/User/globalStorage/codeium.windsurf/config/mcp_config.json"
    echo ""
    echo "2️⃣ 复制以下配置（已自动替换用户名为: $USERNAME）："
    echo ""
    echo "{"
    echo "  \"mcpServers\": {"
    echo "    \"supabase-local\": {"
    echo "      \"command\": \"/Users/$USERNAME/supabase-mcp-local/venv/bin/python\","
    echo "      \"args\": ["
    echo "        \"/Users/$USERNAME/supabase-mcp-local/server.py\""
    echo "      ],"
    echo "      \"env\": {"
    echo "        \"SUPABASE_URL\": \"https://supabase-api.nexus-tech.cloud\","
    echo "        \"SUPABASE_SERVICE_KEY\": \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoic2VydmljZV9yb2xlIiwiaXNzIjoic3VwYWJhc2UiLCJpYXQiOjE2NDE3NjkyMDAsImV4cCI6MTc5OTUzNTYwMH0.d154rW2zWFTARtKnztZLuuV6Bv3qCsLAPVbGLTyYA98\""
    echo "      }"
    echo "    }"
    echo "  }"
    echo "}"
    echo ""
    echo "3️⃣ 重启Windsurf IDE（Cmd+Q 然后重新打开）"
    echo ""
    echo "4️⃣ 在Windsurf中测试："
    echo "   使用supabase-local的list_tables工具列出所有表"
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo "📖 详细文档请查看: INSTALL_GUIDE.md"
    echo ""
else
    echo ""
    echo "❌ 测试失败！请检查："
    echo "1. VPS网络是否可达"
    echo "2. 依赖是否正确安装"
    echo "3. 查看 INSTALL_GUIDE.md 获取帮助"
    echo ""
fi
