# Supabase MCP - Local Development Version

## ✅ 已完成设置

1. **虚拟环境已创建**: `~/supabase-mcp-local/venv`
2. **依赖已安装**: mcp, supabase, httpx
3. **exec_sql函数已验证**: 在VPS数据库中正常工作
4. **测试通过**: test_local.py 成功运行

## 📋 Windsurf IDE 配置

### 方法1: 使用本地Python环境（推荐用于调试）

复制以下内容到Windsurf的MCP配置文件：

**配置文件位置:**
```
~/Library/Application Support/Windsurf/User/globalStorage/codeium.windsurf/config/mcp_config.json
```

**配置内容:**
```json
{
  "mcpServers": {
    "supabase-local": {
      "command": "/Users/wenxinwei/supabase-mcp-local/venv/bin/python",
      "args": [
        "/Users/wenxinwei/supabase-mcp-local/server.py"
      ],
      "env": {
        "SUPABASE_URL": "https://supabase-api.nexus-tech.cloud",
        "SUPABASE_SERVICE_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoic2VydmljZV9yb2xlIiwiaXNzIjoic3VwYWJhc2UiLCJpYXQiOjE2NDE3NjkyMDAsImV4cCI6MTc5OTUzNTYwMH0.d154rW2zWFTARtKnztZLuuV6Bv3qCsLAPVbGLTyYA98"
      }
    }
  }
}
```

### 方法2: 如果已有其他MCP服务器

在现有的 `mcpServers` 对象中添加：

```json
"supabase-local": {
  "command": "/Users/wenxinwei/supabase-mcp-local/venv/bin/python",
  "args": ["/Users/wenxinwei/supabase-mcp-local/server.py"],
  "env": {
    "SUPABASE_URL": "https://supabase-api.nexus-tech.cloud",
    "SUPABASE_SERVICE_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoic2VydmljZV9yb2xlIiwiaXNzIjoic3VwYWJhc2UiLCJpYXQiOjE2NDE3NjkyMDAsImV4cCI6MTc5OTUzNTYwMH0.d154rW2zWFTARtKnztZLuuV6Bv3qCsLAPVbGLTyYA98"
  }
}
```

## 🧪 验证安装

### 1. 运行本地测试
```bash
cd ~/supabase-mcp-local
source venv/bin/activate
python3 test_local.py
```

应该看到：
```
✅ All tests passed!
```

### 2. 在Windsurf中测试

重启Windsurf IDE后，在AI对话中测试：

**测试1: 列出表**
```
使用supabase-local的list_tables工具列出所有表
```

**测试2: 执行SQL**
```
使用supabase-local的execute_sql工具执行: SELECT * FROM user_profiles LIMIT 3;
```

## 📁 项目结构

```
~/supabase-mcp-local/
├── server.py              # MCP服务器主文件（可直接编辑调试）
├── requirements.txt       # Python依赖
├── test_local.py         # 本地测试脚本
├── windsurf_config.json  # Windsurf配置示例
├── venv/                 # Python虚拟环境
└── README.md            # 本文件
```

## 🛠️ 调试技巧

### 修改代码后重新加载

1. 编辑 `server.py`
2. 重启Windsurf IDE（Cmd+Q 然后重新打开）
3. MCP会自动加载最新代码

### 查看详细错误

在 `server.py` 中已添加详细的traceback输出，错误会显示在Windsurf的MCP日志中。

### 直接测试函数

可以修改 `test_local.py` 来测试特定功能：

```python
# 测试list_tables
sql = "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public';"
response = client.rpc("exec_sql", {"query": sql}).execute()
print(response.data)
```

## 🔧 已修复的问题

1. ✅ **pg_tables路径错误** - 改用 information_schema.tables
2. ✅ **exec_sql函数缺失** - 已在VPS数据库创建
3. ✅ **JSON解析错误** - 添加了灵活的响应格式处理
4. ✅ **字符串vs对象** - 处理多种返回格式

## 📊 exec_sql返回格式

从测试结果看，`exec_sql` 返回格式为：

```json
{
  "data": [
    {"table_name": "department_members"},
    {"table_name": "departments"},
    ...
  ],
  "status": "success"
}
```

`list_tables` 函数已适配此格式。

## 🎯 可用工具列表

1. **read_table_rows** - 读取表数据（支持过滤、排序、分页）
2. **create_table_records** - 插入记录
3. **update_table_records** - 更新记录
4. **delete_table_records** - 删除记录
5. **execute_sql** - 执行任意SQL（DDL/DML/SELECT）
6. **list_tables** - 列出所有表
7. **describe_table** - 查看表结构
8. **create_table** - 创建新表

## 🚀 下一步

1. 复制配置到Windsurf的MCP配置文件
2. 重启Windsurf IDE
3. 在AI对话中测试工具
4. 如有问题，查看本地测试输出调试

## ⚠️ 注意事项

- 本地开发版直接运行Python脚本，便于调试
- 修改 `server.py` 后需重启Windsurf
- 所有文件都在 `~/supabase-mcp-local/` 目录
- 虚拟环境已包含所有依赖

## 📞 故障排查

### MCP连接失败

1. 确认虚拟环境存在：`ls ~/supabase-mcp-local/venv`
2. 测试本地连接：`cd ~/supabase-mcp-local && source venv/bin/activate && python3 test_local.py`
3. 检查配置文件路径是否正确

### exec_sql不存在

在VPS上重新创建：
```bash
ssh root@100.112.168.22 "docker exec -i supabase-db psql -U postgres -d postgres < /tmp/create_exec_sql.sql"
```

### 修改不生效

完全退出Windsurf（Cmd+Q）然后重新启动，而不是只关闭窗口。
