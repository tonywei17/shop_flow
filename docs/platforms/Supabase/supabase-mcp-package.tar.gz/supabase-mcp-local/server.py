"""Enhanced Supabase MCP Server - Local Debug Version"""

import json
import os
from typing import Any, Dict, List
from mcp.server import Server
from mcp.types import Tool, TextContent
from supabase import create_client, Client

SUPABASE_CLIENT: Client = None

def get_client() -> Client:
    """Get or initialize Supabase client."""
    global SUPABASE_CLIENT
    if SUPABASE_CLIENT is None:
        url = os.getenv("SUPABASE_URL")
        key = os.getenv("SUPABASE_SERVICE_KEY")
        
        if not url or not key:
            raise ValueError(
                "Missing environment variables. Please set SUPABASE_URL and SUPABASE_SERVICE_KEY."
            )
        
        SUPABASE_CLIENT = create_client(url, key)
    
    return SUPABASE_CLIENT


app = Server("supabase-enhanced")


@app.list_tools()
async def list_tools() -> list[Tool]:
    """List available tools."""
    return [
        Tool(
            name="read_table_rows",
            description="Read rows from a Supabase table with optional filtering, ordering, and pagination",
            inputSchema={
                "type": "object",
                "properties": {
                    "table_name": {"type": "string", "description": "Name of the table to read from"},
                    "columns": {"type": "string", "description": "Comma-separated list of columns to select (default: '*' for all)", "default": "*"},
                    "filters": {"type": "object", "description": "Dictionary of column-value pairs for filtering (uses equality)", "additionalProperties": True},
                    "limit": {"type": "integer", "description": "Maximum number of rows to return"},
                    "order_by": {"type": "string", "description": "Column name to order results by"},
                    "ascending": {"type": "boolean", "description": "Sort order (true for ascending, false for descending)", "default": True}
                },
                "required": ["table_name"]
            }
        ),
        Tool(
            name="create_table_records",
            description="Insert one or more records into a Supabase table",
            inputSchema={
                "type": "object",
                "properties": {
                    "table_name": {"type": "string", "description": "Name of the table to insert into"},
                    "records": {"description": "Single record (object) or array of records to insert", "oneOf": [{"type": "object"}, {"type": "array", "items": {"type": "object"}}]}
                },
                "required": ["table_name", "records"]
            }
        ),
        Tool(
            name="update_table_records",
            description="Update records in a Supabase table matching specified filters",
            inputSchema={
                "type": "object",
                "properties": {
                    "table_name": {"type": "string", "description": "Name of the table to update"},
                    "updates": {"type": "object", "description": "Dictionary of column-value pairs to update"},
                    "filters": {"type": "object", "description": "Dictionary of column-value pairs to filter which rows to update"}
                },
                "required": ["table_name", "updates", "filters"]
            }
        ),
        Tool(
            name="delete_table_records",
            description="Delete records from a Supabase table matching specified filters",
            inputSchema={
                "type": "object",
                "properties": {
                    "table_name": {"type": "string", "description": "Name of the table to delete from"},
                    "filters": {"type": "object", "description": "Dictionary of column-value pairs to filter which rows to delete"}
                },
                "required": ["table_name", "filters"]
            }
        ),
        Tool(
            name="execute_sql",
            description="Execute raw SQL query on the Supabase database (DDL, DML, queries). Use this for CREATE TABLE, ALTER TABLE, complex queries, etc.",
            inputSchema={
                "type": "object",
                "properties": {
                    "sql": {"type": "string", "description": "SQL query to execute (can be SELECT, INSERT, UPDATE, DELETE, CREATE TABLE, etc.)"}
                },
                "required": ["sql"]
            }
        ),
        Tool(
            name="list_tables",
            description="List all tables in the public schema",
            inputSchema={"type": "object", "properties": {}}
        ),
        Tool(
            name="describe_table",
            description="Get detailed schema information for a specific table",
            inputSchema={
                "type": "object",
                "properties": {
                    "table_name": {"type": "string", "description": "Name of the table to describe"}
                },
                "required": ["table_name"]
            }
        ),
        Tool(
            name="create_table",
            description="Create a new table with specified columns and constraints",
            inputSchema={
                "type": "object",
                "properties": {
                    "table_name": {"type": "string", "description": "Name of the table to create"},
                    "columns": {
                        "type": "array",
                        "description": "Array of column definitions",
                        "items": {
                            "type": "object",
                            "properties": {
                                "name": {"type": "string", "description": "Column name"},
                                "type": {"type": "string", "description": "PostgreSQL data type (e.g., text, integer, uuid, timestamp)"},
                                "primary_key": {"type": "boolean", "description": "Is this a primary key?", "default": False},
                                "nullable": {"type": "boolean", "description": "Can this be null?", "default": True},
                                "default": {"type": "string", "description": "Default value expression (e.g., 'now()', '0')"},
                                "unique": {"type": "boolean", "description": "Must values be unique?", "default": False}
                            },
                            "required": ["name", "type"]
                        }
                    }
                },
                "required": ["table_name", "columns"]
            }
        )
    ]


@app.call_tool()
async def call_tool(name: str, arguments: Any) -> list[TextContent]:
    """Handle tool calls."""
    try:
        client = get_client()
        
        if name == "read_table_rows":
            result = await read_table_rows(client, arguments)
        elif name == "create_table_records":
            result = await create_table_records(client, arguments)
        elif name == "update_table_records":
            result = await update_table_records(client, arguments)
        elif name == "delete_table_records":
            result = await delete_table_records(client, arguments)
        elif name == "execute_sql":
            result = await execute_sql(client, arguments)
        elif name == "list_tables":
            result = await list_tables(client)
        elif name == "describe_table":
            result = await describe_table(client, arguments)
        elif name == "create_table":
            result = await create_table(client, arguments)
        else:
            raise ValueError(f"Unknown tool: {name}")
        
        return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]
    
    except Exception as e:
        import traceback
        error_detail = traceback.format_exc()
        return [TextContent(
            type="text",
            text=json.dumps({"error": str(e), "detail": error_detail, "status": "error"}, indent=2)
        )]


async def read_table_rows(client: Client, args: Dict) -> List[Dict]:
    """Read rows from a table."""
    query = client.table(args["table_name"]).select(args.get("columns", "*"))
    
    if filters := args.get("filters"):
        for key, value in filters.items():
            query = query.eq(key, value)
    
    if order_by := args.get("order_by"):
        query = query.order(order_by, desc=not args.get("ascending", True))
    
    if limit := args.get("limit"):
        query = query.limit(limit)
    
    response = query.execute()
    return response.data


async def create_table_records(client: Client, args: Dict) -> Dict:
    """Create records in a table."""
    response = client.table(args["table_name"]).insert(args["records"]).execute()
    return {"data": response.data, "count": len(response.data) if response.data else 0, "status": "success"}


async def update_table_records(client: Client, args: Dict) -> Dict:
    """Update records in a table."""
    query = client.table(args["table_name"]).update(args["updates"])
    for key, value in args["filters"].items():
        query = query.eq(key, value)
    response = query.execute()
    return {"data": response.data, "count": len(response.data) if response.data else 0, "status": "success"}


async def delete_table_records(client: Client, args: Dict) -> Dict:
    """Delete records from a table."""
    query = client.table(args["table_name"]).delete()
    for key, value in args["filters"].items():
        query = query.eq(key, value)
    response = query.execute()
    return {"data": response.data, "count": len(response.data) if response.data else 0, "status": "success"}


async def execute_sql(client: Client, args: Dict) -> Dict:
    """Execute raw SQL query via PostgREST RPC."""
    sql = args["sql"].strip()
    try:
        response = client.rpc("exec_sql", {"query": sql}).execute()
        
        # Parse response - it could be a string or dict
        data = response.data
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except:
                pass
        
        # If data is dict with 'data' key, extract it
        if isinstance(data, dict):
            if "data" in data:
                return {"result": data["data"], "status": "success"}
            elif "error" in data:
                return {"error": data["error"], "status": "error"}
        
        return {"result": data, "status": "success"}
        
    except Exception as e:
        error_str = str(e)
        if "function public.exec_sql" in error_str.lower() and "does not exist" in error_str.lower():
            return {
                "error": "exec_sql function not found",
                "status": "error",
                "solution": "The exec_sql RPC function is not created in the database. Please create it first."
            }
        else:
            raise


async def list_tables(client: Client) -> Dict:
    """List all tables in the public schema."""
    # Use exec_sql to query information_schema
    sql = "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE' ORDER BY table_name;"
    
    try:
        result = await execute_sql(client, {"sql": sql})
        
        if result.get("status") == "success" and "result" in result:
            result_data = result["result"]
            
            # Handle different response formats
            tables = []
            if isinstance(result_data, list):
                for item in result_data:
                    if isinstance(item, dict) and "table_name" in item:
                        tables.append(item["table_name"])
                    elif isinstance(item, str):
                        tables.append(item)
            elif isinstance(result_data, dict) and "data" in result_data:
                # Nested data structure
                for item in result_data["data"]:
                    if isinstance(item, dict) and "table_name" in item:
                        tables.append(item["table_name"])
            
            return {"tables": tables, "count": len(tables), "status": "success"}
        else:
            return {"tables": [], "count": 0, "status": "error", "error": result.get("error", "Unknown error")}
            
    except Exception as e:
        import traceback
        return {
            "tables": [], 
            "count": 0, 
            "status": "error", 
            "error": str(e),
            "traceback": traceback.format_exc()
        }


async def describe_table(client: Client, args: Dict) -> Dict:
    """Get table schema information."""
    table_name = args["table_name"]
    sql = f"""
    SELECT column_name, data_type, is_nullable, column_default
    FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = '{table_name}'
    ORDER BY ordinal_position;
    """
    result = await execute_sql(client, {"sql": sql})
    
    if result.get("status") == "success" and "result" in result:
        return {"table": table_name, "columns": result["result"], "status": "success"}
    return {"table": table_name, "error": "Could not retrieve schema", "status": "error"}


async def create_table(client: Client, args: Dict) -> Dict:
    """Create a new table using SQL generation."""
    table_name = args["table_name"]
    columns = args["columns"]
    
    column_defs = []
    for col in columns:
        col_def = f"{col['name']} {col['type']}"
        if col.get("primary_key"):
            col_def += " PRIMARY KEY"
        if not col.get("nullable", True) and not col.get("primary_key"):
            col_def += " NOT NULL"
        if default := col.get("default"):
            col_def += f" DEFAULT {default}"
        if col.get("unique") and not col.get("primary_key"):
            col_def += " UNIQUE"
        column_defs.append(col_def)
    
    sql = f"CREATE TABLE {table_name} (\n  " + ",\n  ".join(column_defs) + "\n);"
    result = await execute_sql(client, {"sql": sql})
    result["sql"] = sql
    return result


async def main():
    """Run the MCP server."""
    from mcp.server.stdio import stdio_server
    
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
