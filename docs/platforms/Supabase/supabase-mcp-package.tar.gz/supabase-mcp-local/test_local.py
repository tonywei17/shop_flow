#!/usr/bin/env python3
"""Local test script for Supabase MCP"""

import os
import asyncio
from supabase import create_client

# Set environment variables
os.environ["SUPABASE_URL"] = "https://supabase-api.nexus-tech.cloud"
os.environ["SUPABASE_SERVICE_KEY"] = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoic2VydmljZV9yb2xlIiwiaXNzIjoic3VwYWJhc2UiLCJpYXQiOjE2NDE3NjkyMDAsImV4cCI6MTc5OTUzNTYwMH0.d154rW2zWFTARtKnztZLuuV6Bv3qCsLAPVbGLTyYA98"

async def test_exec_sql():
    """Test exec_sql function"""
    print("🧪 Testing exec_sql function...")
    client = create_client(
        os.environ["SUPABASE_URL"],
        os.environ["SUPABASE_SERVICE_KEY"]
    )
    
    try:
        # Test 1: List tables
        print("\n1️⃣ Test: List tables via exec_sql")
        sql = "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE' ORDER BY table_name LIMIT 5;"
        response = client.rpc("exec_sql", {"query": sql}).execute()
        print(f"   Response type: {type(response.data)}")
        print(f"   Response data: {response.data}")
        
        # Test 2: Check exec_sql function exists
        print("\n2️⃣ Test: Verify exec_sql function exists")
        sql2 = "SELECT routine_name FROM information_schema.routines WHERE routine_name = 'exec_sql';"
        response2 = client.rpc("exec_sql", {"query": sql2}).execute()
        print(f"   Response: {response2.data}")
        
        print("\n✅ All tests passed!")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_exec_sql())
